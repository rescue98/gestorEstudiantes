package com.example.demo.service;

import com.example.demo.model.Estudiante;

import java.util.List;

public interface EstudianteService {
    List<Estudiante> getAllEstudiante();


    static Estudiante guardarEstudiante(Estudiante estudiante) {
        return null;
    }

    static Estudiante getEstudianteById(int id);
    Estudiante updateEstudiante( Estudiante estudiante);
    void deleteEstudianteById( int id);

}
