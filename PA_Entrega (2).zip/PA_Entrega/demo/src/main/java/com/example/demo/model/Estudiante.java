package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name = "estudiantes")

public class Estudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column (name = "nombre", nullable = false)
    private String nombre;

    @Column (name = "apellido")
    private String apellido;

    @Column (name = "cursoAsignado")
    private String cursoAsignado;

    public Estudiante() {

    }
    public Estudiante(String nombre, String apellido, String cursoAsignado) {
        super();
        this.nombre = nombre;
        this.apellido = apellido;
        this.cursoAsignado = cursoAsignado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCursoAsignado() {
        return cursoAsignado;
    }

    public void setCursoAsignado(String cursoAsignado) {
        this.cursoAsignado = cursoAsignado;
    }
}
