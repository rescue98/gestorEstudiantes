package com.example.demo.estImplement;

import com.example.demo.model.Estudiante;
import com.example.demo.repository.EstudianteRepository;
import com.example.demo.service.EstudianteService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class estImplement implements EstudianteService {

    private EstudianteRepository estudianteRepository;

    public estImplement(EstudianteRepository estudianteRepository){
        super();
        this.estudianteRepository= estudianteRepository;
    }

    @Override
    public List<Estudiante> getAllEstudiante() {
        return EstudianteRepository.findAll();
    }


    public Estudiante guardarEstudiante(Estudiante estudiante){
        return EstudianteRepository.guardarEstudiante(estudiante);
    }

    @Override
    public Estudiante getEstudianteById(int id) {
        return null;
    }

    @Override
    public Estudiante updateEstudiante(Estudiante estudiante) {
        return EstudianteRepository.guardarEstudiante(estudiante);
    }

    @Override
    public void deleteEstudianteById(int id) {

    }
}
