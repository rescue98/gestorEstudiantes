package com.example.demo.controller;


import com.example.demo.model.Estudiante;
import com.example.demo.service.EstudianteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EstudianteController {

    private EstudianteService estudianteService;

    public EstudianteController(EstudianteService estudianteService){
        super();
        this.estudianteService = estudianteService;
    }

    //manejar lista de estudiantes

    @GetMapping("/estudiantes") //este estudiante es el nombre de la tabla BD para guardar datos
    public String listEstudiante(Model model){
        model.addAttribute("estudiantes", estudianteService.getAllEstudiante());
        return "estudiantes";
    }

    @GetMapping("/estudiantes/new")
    public String crearEstudianteForm (Model model){

        Estudiante estudiante = new Estudiante();
        model.addAttribute("estudiante", estudiante);
        return "crearEstudiante";
    }

    @GetMapping("estudiantes/edit/{id}")
    public String editStudentForm(@PathVariable int Id, Model model){
    model.addAttribute("estudiante", EstudianteService.getEstudianteById(Id));
    return "crearEstudiante";
    }

    @PostMapping("/estudiantes")
    public String guardarEstudiante(@ModelAttribute("estudiante") Estudiante estudiante){
        EstudianteService.guardarEstudiante(estudiante);
        return "redirect:/estudiantes";
    }
    @PostMapping("/estudiantes/{id}")
    public String updateEstudiante(@PathVariable int Id, @ModelAttribute("estudiante"), Estudiante estudiante, Model model){

        Estudiante estudianteRegistrado = EstudianteService.getEstudianteById(Id);
        estudianteRegistrado.setId(Id);
        estudianteRegistrado.setNombre(estudiante.getNombre());
        estudianteRegistrado.setApellido(estudiante.getApellido());
        estudianteRegistrado.setCursoAsignado(estudiante.getCursoAsignado());

    EstudianteService.guardarEstudiante(estudianteRegistrado);
    return "redirect:/estudiantes";

    }


}
