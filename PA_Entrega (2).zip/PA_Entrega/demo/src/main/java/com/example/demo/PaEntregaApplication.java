package com.example.demo;

import com.example.demo.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaEntregaApplication implements CommandLineRunner {

	public static void main(String[] args) {

		SpringApplication.run(PaEntregaApplication.class, args);
	}

	@Autowired
	private EstudianteRepository estudianteRepository;

	@Override
	public void run(String... args) throws Exception {

	}
}
