package com.example.demo.repository;


import com.example.demo.model.Estudiante;
import org.springframework.data.repository.CrudRepository;

public interface EstudianteRepository extends CrudRepository<Estudiante, Integer> {


    static Estudiante guardarEstudiante(Estudiante estudiante) {
        return estudiante;
    }
}
